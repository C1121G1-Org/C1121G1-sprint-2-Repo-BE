package api.dto;

public interface Top100Dto {
    Long getId();
    String getName();
    String getImage();
    Double getValue();
    String getTotalLike();
}
