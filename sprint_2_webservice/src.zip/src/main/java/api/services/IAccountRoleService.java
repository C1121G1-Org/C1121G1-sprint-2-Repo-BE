package api.services;

import api.models.Account;

public interface IAccountRoleService{

    /*
        Created by khoaVC
        Role: GUEST
        Time: 20:00 16/06/2022
        Function: create = create AccountRole
        Class:
    */
    void create(Account account, Long i);
}
