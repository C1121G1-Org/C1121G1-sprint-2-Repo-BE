package api.services;

public interface ICategoryGiftService {
}
