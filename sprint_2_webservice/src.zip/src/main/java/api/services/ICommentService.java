package api.services;

public interface ICommentService {
}
