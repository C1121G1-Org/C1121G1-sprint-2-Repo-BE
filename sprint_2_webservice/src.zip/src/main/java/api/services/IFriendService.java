package api.services;

public interface IFriendService {
}
