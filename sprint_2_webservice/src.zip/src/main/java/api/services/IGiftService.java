package api.services;

public interface IGiftService {
}
