package api.services;

public interface IGuestFavoriteService {
}
