package api.services;

public interface IGuestReportService {
}
