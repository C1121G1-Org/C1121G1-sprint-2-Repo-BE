package api.services;

public interface IGuestTargetService {

/*
    Created by khoaVC
    Role: MEMBER
    Time: 23:00 15/06/2022
    Function: create = create record for target list
    Class:
*/
    void create(Long id, Integer i);
}
