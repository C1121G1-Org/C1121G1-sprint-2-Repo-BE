package api.services;

public interface ILikeCommentService {
}
