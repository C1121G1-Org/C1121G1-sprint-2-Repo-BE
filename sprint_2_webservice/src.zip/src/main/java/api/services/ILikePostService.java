package api.services;

public interface ILikePostService {
}
