package api.services;

public interface IPostService {
}
