package api.services;

public interface IReportService {
}
