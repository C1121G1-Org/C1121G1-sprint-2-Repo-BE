package api.services;

public interface IRoleService {
}
